# Surface Plasmon Model

`surface-plasmon-model` is a Python package for modelling surface plasmon polaritons (SPPs) at planar metal–dielectric interfaces.

The package is being developed as part of a computational investigation into the electromagnetic properties of surface plasmons, including their dispersion, propagation and interaction with different material systems.

## Background

A surface plasmon polariton is an electromagnetic surface wave coupled to collective oscillations of free electrons at a metal–dielectric interface.

For a planar interface, the SPP wavevector is

$$
k_{\mathrm{SPP}}
=
\frac{\omega}{c}
\sqrt{
\frac{\varepsilon_m\varepsilon_d}
{\varepsilon_m+\varepsilon_d}
}.
$$

Here:

* \(\omega\) is angular frequency
* \(c\) is the speed of light
* \(\varepsilon_m\) is the complex relative permittivity of the metal
* \(\varepsilon_d\) is the relative permittivity of the dielectric

## Current Features

Version `0.1.1` currently provides:

* complex metal permittivity using the Drude model
* planar metal–dielectric SPP wavevector calculations
* complex-valued calculations for lossy materials
* calculations over individual frequencies or NumPy arrays
* compatibility with NumPy, SciPy, Matplotlib and Pandas

## Planned Features

Future versions are intended to include:

* SPP dispersion curves
* propagation length
* SPP wavelength
* penetration depth into the metal and dielectric
* electromagnetic field profiles
* gold, silver and aluminium material models
* different dielectric environments
* experimental optical-constant datasets
* Drude–Lorentz material modelling
* comparison between theoretical and experimental dielectric functions

## Installation

Once available from PyPI:

```bash
python -m pip install surface-plasmon-model
```

For development from the source project:

```bash
python -m pip install -e .
```

## Basic Usage

```python
import numpy as np
from scipy.constants import c

from surface_plasmon_model import (
    drude_permittivity,
    spp_wavevector,
)

wavelength = 632.8e-9
omega = 2 * np.pi * c / wavelength

epsilon_m = drude_permittivity(
    omega,
    epsilon_inf=9.5,
    omega_p=1.37e16,
    gamma=1.05e14,
)

epsilon_d = 1.0

k_spp = spp_wavevector(
    omega,
    epsilon_m,
    epsilon_d,
)

print("Metal permittivity:", epsilon_m)
print("SPP wavevector:", k_spp)
```

## Drude Model

The current metal model uses the Drude dielectric function

$$
\varepsilon_m(\omega)
=
\varepsilon_\infty
-
\frac{\omega_p^2}
{\omega^2+i\gamma\omega}.
$$

The parameters are:

* \(\varepsilon_\infty\): high-frequency contribution to the permittivity
* \(\omega_p\): plasma frequency
* \(\gamma\): damping frequency

Because the dielectric function is complex,

$$
\varepsilon_m
=
\varepsilon_m'
+
i\varepsilon_m'',
$$

the model can represent both dispersion and material loss.

## Project Structure

```text
Surface_Plasmons/
├── notebooks/
├── src/
│   └── surface_plasmon_model/
│       ├── __init__.py
│       ├── drude.py
│       └── spp.py
├── LICENSE
├── pyproject.toml
└── README.md
```

## Development Status

This package is currently an early research release.

The API, numerical implementation and material models may change as the project develops and additional validation is performed.

## License

Distributed under the MIT License. See the `LICENSE` file for details.

## Testing

Install the development dependencies using:

```bash
python -m pip install -e ".[dev]"